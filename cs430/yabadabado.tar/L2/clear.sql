drop table BorrowedBy, WrittenBy, AuthorPhone, PublisherPhone, PublishedBy;

drop table Book, Author, Member, Publisher;
