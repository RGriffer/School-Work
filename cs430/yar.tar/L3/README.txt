README
3. Cannot delete author that has books.

8. Cannot add a book with a publisher that does not exist.
