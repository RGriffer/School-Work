drop table BorrowedBy, WrittenBy, AuthorPhone, PublisherPhone, PublishedBy, LocatedAt;

drop table Book, Author, Member, Publisher, Library;
