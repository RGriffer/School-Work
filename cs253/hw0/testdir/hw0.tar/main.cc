#include <iostream>
using namespace std;

int main() {
	
	// How many programmers does it take to screw in a lightbulb?
	cout << "None. That's a hardware problem.\n"
	"Funny right?\n";

	return 0;
	}
